Dead County 3D v0.4.3 — Test correction zombies. Godot 4.7.2.
Camera stable conservee. Appuyez F5, jouer solo.
Si Zombies : 0, ouvrir le Debugger et envoyer les erreurs rouges.
