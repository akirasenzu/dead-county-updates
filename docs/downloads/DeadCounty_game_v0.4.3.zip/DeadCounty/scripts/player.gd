extends CharacterBody3D

# v0.3 - Controles 3e personne: mouvement relatif a la camera.
var player_id: int = 1
var health := 100
var target_position := Vector3.ZERO
var target_yaw := 0.0
var camera: Camera3D
var camera_yaw := 0.0
var camera_pitch := -0.18
var camera_pivot: Node3D
var camera_tilt: Node3D
const SurvivorVisual = preload("res://scripts/survivor_visual.gd")
var body_visual: Node3D
var update_timer := 0.0
var is_crouching := false

const WALK_SPEED := 4.2
const RUN_SPEED := 7.8
const CROUCH_SPEED := 2.1
const ACCELERATION := 13.0
const FRICTION := 17.0
const MOUSE_SENSITIVITY := 0.0027

func setup(id: int) -> void:
    player_id = id
    name = "Player_%d" % id
    set_multiplayer_authority(id)
    position = Vector3(float((id % 5) * 3), 2, float((id / 5) * 3))
    target_position = position

func _ready() -> void:
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.8
    collision.shape = shape
    collision.position.y = 0.9
    add_child(collision)
    body_visual = Node3D.new()
    body_visual.name = "Survivant_3D"
    body_visual.set_script(SurvivorVisual)
    add_child(body_visual)
    if is_multiplayer_authority():
        camera_pivot = Node3D.new()
        camera_pivot.position = Vector3(0, 1.45, 0)
        add_child(camera_pivot)
        # Independent du pivot du joueur : pas de rotation parasite.
        camera_pivot.set_as_top_level(true)
        camera_pivot.global_position = global_position + Vector3(0, 1.45, 0)
        camera_tilt = Node3D.new()
        camera_pivot.add_child(camera_tilt)
        camera = Camera3D.new()
        camera.position = Vector3(0.65, 1.1, 5.6)
        camera.rotation.x = -0.14
        camera.current = true
        camera_tilt.add_child(camera)
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if not is_multiplayer_authority():
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        else:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        camera_yaw -= event.relative.x * MOUSE_SENSITIVITY
        camera_pitch = clamp(camera_pitch - event.relative.y * MOUSE_SENSITIVITY, -0.85, 0.45)
        camera_pivot.rotation.y = camera_yaw
        camera_tilt.rotation.x = camera_pitch

func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority():
        position = position.lerp(target_position, min(1.0, delta * 12.0))
        rotation.y = lerp_angle(rotation.y, target_yaw, min(1.0, delta * 12.0))
        if body_visual != null:
            body_visual.update_pose(delta, Vector2(target_position.x - position.x, target_position.z - position.z).length() * 12.0, false, true)
        return

    var axis := Vector2.ZERO
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_Z): axis.y += 1
    if Input.is_key_pressed(KEY_S): axis.y -= 1
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_Q): axis.x -= 1
    if Input.is_key_pressed(KEY_D): axis.x += 1
    axis = axis.normalized()
    if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        axis = Vector2.ZERO

    is_crouching = Input.is_key_pressed(KEY_CTRL) and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
    var sprinting := Input.is_key_pressed(KEY_SHIFT) and not is_crouching and axis.y > 0
    var chosen_speed := CROUCH_SPEED if is_crouching else (RUN_SPEED if sprinting else WALK_SPEED)
    var camera_forward := Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
    var camera_right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
    var direction := (camera_right * axis.x + camera_forward * axis.y).normalized()
    var target_velocity := direction * chosen_speed
    var response := ACCELERATION if axis.length_squared() > 0.01 else FRICTION
    velocity.x = move_toward(velocity.x, target_velocity.x, response * delta)
    velocity.z = move_toward(velocity.z, target_velocity.z, response * delta)
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    elif Input.is_key_pressed(KEY_SPACE) and not is_crouching and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        velocity.y = 7.4
    else:
        velocity.y = 0.0
    move_and_slide()

    if direction.length_squared() > 0.05:
        var wanted_angle := atan2(-direction.x, -direction.z)
        rotation.y = lerp_angle(rotation.y, wanted_angle, min(1.0, delta * 12.0))

    # Animations procedurales du survivant, sans modifier la collision existante.
    body_visual.update_pose(delta, Vector2(velocity.x, velocity.z).length(), is_crouching, is_on_floor())

    # Suit uniquement la position du joueur. Sa rotation reste geree par la souris.
    camera_pivot.global_position = global_position + Vector3(0, 1.45, 0)

    update_timer += delta
    if update_timer > 0.05 and multiplayer.has_multiplayer_peer():
        update_timer = 0.0
        sync_position.rpc(position, rotation.y)

@rpc("any_peer", "unreliable")
func sync_position(new_pos: Vector3, yaw: float) -> void:
    if multiplayer.get_remote_sender_id() != player_id: return
    if is_multiplayer_authority(): return
    target_position = new_pos
    target_yaw = yaw
