extends Node3D
# v0.4.1 semi-realiste : survivant procedural plus detaille mais toujours leger.
# Origine au niveau des pieds. Aucune dependance externe.
var hips: Node3D
var spine: Node3D
var chest: Node3D
var head: Node3D
var left_upper_arm: Node3D
var right_upper_arm: Node3D
var left_forearm: Node3D
var right_forearm: Node3D
var left_thigh: Node3D
var right_thigh: Node3D
var left_calf: Node3D
var right_calf: Node3D
var left_foot: Node3D
var right_foot: Node3D
var motion_time := 0.0
var crouch_blend := 0.0
var ground_blend := 1.0

func _material(c: Color, roughness := 0.88, metallic := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = roughness
    m.metallic = metallic
    return m

func _box(parent: Node3D, label: String, dimensions: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = label
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    item.mesh = mesh
    item.position = pos
    item.material_override = mat
    parent.add_child(item)
    return item

func _ball(parent: Node3D, label: String, radius: float, pos: Vector3, mat: Material) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = label
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    item.mesh = mesh
    item.position = pos
    item.material_override = mat
    parent.add_child(item)
    return item

func _capsule(parent: Node3D, label: String, radius: float, height: float, pos: Vector3, mat: Material) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = label
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = height
    item.mesh = mesh
    item.position = pos
    item.material_override = mat
    parent.add_child(item)
    return item

func _joint(name_str: String, position_3d: Vector3, parent: Node3D = self) -> Node3D:
    var node := Node3D.new()
    node.name = name_str
    node.position = position_3d
    parent.add_child(node)
    return node

func _ready() -> void:
    var jacket := _material(Color(0.16, 0.23, 0.22))
    var jacket_dark := _material(Color(0.08, 0.12, 0.12))
    var shirt := _material(Color(0.26, 0.36, 0.31))
    var pants := _material(Color(0.16, 0.18, 0.23))
    var boots := _material(Color(0.07, 0.06, 0.06))
    var skin := _material(Color(0.71, 0.55, 0.44), 0.95)
    var hair := _material(Color(0.10, 0.08, 0.06), 0.95)
    var backpack := _material(Color(0.24, 0.22, 0.14))
    var metal := _material(Color(0.34, 0.35, 0.38), 0.42, 0.15)

    hips = _joint('Hips', Vector3(0, 0.96, 0))
    _box(hips, 'Bassin', Vector3(0.38, 0.20, 0.22), Vector3(0, 0.0, 0), pants)

    spine = _joint('Spine', Vector3(0, 0.17, 0), hips)
    _capsule(spine, 'Abdomen', 0.19, 0.42, Vector3(0, 0.14, 0), shirt)
    chest = _joint('Chest', Vector3(0, 0.43, 0), spine)
    _capsule(chest, 'Poitrine', 0.23, 0.52, Vector3(0, 0.10, -0.01), jacket)
    _box(chest, 'Zip', Vector3(0.04, 0.44, 0.03), Vector3(0, 0.10, -0.20), jacket_dark)
    _box(chest, 'Bandouliere_G', Vector3(0.05, 0.48, 0.03), Vector3(-0.14, 0.08, -0.18), backpack)
    _box(chest, 'Bandouliere_D', Vector3(0.05, 0.48, 0.03), Vector3(0.14, 0.08, -0.18), backpack)
    _box(chest, 'Sac', Vector3(0.48, 0.56, 0.18), Vector3(0, 0.06, 0.24), backpack)
    _box(chest, 'Pochette', Vector3(0.28, 0.18, 0.05), Vector3(0, -0.14, 0.37), backpack)
    _box(chest, 'Lampe', Vector3(0.06, 0.12, 0.06), Vector3(0.19, 0.02, -0.20), metal)

    var neck := _joint('Neck', Vector3(0, 0.33, -0.01), chest)
    _capsule(neck, 'Cou', 0.07, 0.12, Vector3(0, 0.03, 0), skin)
    head = _joint('Head', Vector3(0, 0.13, 0), neck)
    _ball(head, 'Crane', 0.22, Vector3(0, 0.16, -0.01), skin)
    _box(head, 'Machoire', Vector3(0.24, 0.14, 0.20), Vector3(0, 0.00, -0.03), skin)
    _box(head, 'Nez', Vector3(0.06, 0.08, 0.08), Vector3(0, 0.06, -0.21), skin)
    _box(head, 'Cheveux_haut', Vector3(0.38, 0.10, 0.34), Vector3(0, 0.28, -0.01), hair)
    _box(head, 'Cheveux_arriere', Vector3(0.32, 0.20, 0.16), Vector3(0, 0.18, 0.09), hair)

    var eye := _material(Color(0.10, 0.10, 0.10))
    var fabric_stitch := _material(Color(0.32, 0.34, 0.30))
    var buckle := _material(Color(0.45, 0.46, 0.45), 0.4, 0.3)
    # Visage et equipement lisibles a distance rapprochee.
    _box(head, 'Sourcil_G', Vector3(0.085, 0.022, 0.024), Vector3(-0.09, 0.15, -0.205), hair)
    _box(head, 'Sourcil_D', Vector3(0.085, 0.022, 0.024), Vector3(0.09, 0.15, -0.205), hair)
    _ball(head, 'Oeil_G', 0.018, Vector3(-0.09, 0.12, -0.205), eye)
    _ball(head, 'Oeil_D', 0.018, Vector3(0.09, 0.12, -0.205), eye)
    _box(head, 'Barbe_discrete', Vector3(0.21, 0.042, 0.02), Vector3(0, -0.044, -0.124), hair)
    _box(chest, 'Couture_veste', Vector3(0.02, 0.39, 0.016), Vector3(-0.18, 0.11, -0.19), fabric_stitch)
    _box(chest, 'Poche_poitrine', Vector3(0.16, 0.12, 0.032), Vector3(0.12, 0.04, -0.20), jacket_dark)
    _box(chest, 'Boucle_sac', Vector3(0.13, 0.06, 0.035), Vector3(0, -0.16, 0.38), buckle)
    _box(chest, 'Trousse_laterale', Vector3(0.15, 0.19, 0.12), Vector3(0.31, -0.07, 0.21), backpack)


    left_upper_arm = _joint('UpperArm_L', Vector3(-0.29, 0.23, 0.0), chest)
    right_upper_arm = _joint('UpperArm_R', Vector3(0.29, 0.23, 0.0), chest)
    _capsule(left_upper_arm, 'BrasHaut_L', 0.09, 0.34, Vector3(0, -0.16, 0), jacket)
    _capsule(right_upper_arm, 'BrasHaut_R', 0.09, 0.34, Vector3(0, -0.16, 0), jacket)
    left_forearm = _joint('Forearm_L', Vector3(0, -0.32, 0.0), left_upper_arm)
    right_forearm = _joint('Forearm_R', Vector3(0, -0.32, 0.0), right_upper_arm)
    _capsule(left_forearm, 'AvantBras_L', 0.078, 0.32, Vector3(0, -0.14, 0), jacket_dark)
    _capsule(right_forearm, 'AvantBras_R', 0.078, 0.32, Vector3(0, -0.14, 0), jacket_dark)
    _box(left_forearm, 'Main_L', Vector3(0.11, 0.14, 0.12), Vector3(0, -0.31, -0.01), skin)
    _box(right_forearm, 'Main_R', Vector3(0.11, 0.14, 0.12), Vector3(0, -0.31, -0.01), skin)

    left_thigh = _joint('Thigh_L', Vector3(-0.12, -0.02, 0), hips)
    right_thigh = _joint('Thigh_R', Vector3(0.12, -0.02, 0), hips)
    _capsule(left_thigh, 'Cuisse_L', 0.11, 0.46, Vector3(0, -0.19, 0), pants)
    _capsule(right_thigh, 'Cuisse_R', 0.11, 0.46, Vector3(0, -0.19, 0), pants)
    left_calf = _joint('Calf_L', Vector3(0, -0.42, 0), left_thigh)
    right_calf = _joint('Calf_R', Vector3(0, -0.42, 0), right_thigh)
    _capsule(left_calf, 'Mollet_L', 0.09, 0.42, Vector3(0, -0.17, 0), pants)
    _capsule(right_calf, 'Mollet_R', 0.09, 0.42, Vector3(0, -0.17, 0), pants)
    left_foot = _joint('Foot_L', Vector3(0, -0.39, 0.01), left_calf)
    right_foot = _joint('Foot_R', Vector3(0, -0.39, 0.01), right_calf)
    _box(left_foot, 'Botte_L', Vector3(0.16, 0.11, 0.32), Vector3(0, -0.03, -0.06), boots)
    _box(right_foot, 'Botte_R', Vector3(0.16, 0.11, 0.32), Vector3(0, -0.03, -0.06), boots)

func update_pose(delta: float, horizontal_speed: float, crouching: bool, on_ground: bool) -> void:
    crouch_blend = move_toward(crouch_blend, 1.0 if crouching else 0.0, delta * 6.5)
    ground_blend = move_toward(ground_blend, 1.0 if on_ground else 0.0, delta * 8.0)

    var walk_strength: float = clampf(horizontal_speed / 4.2, 0.0, 1.0)
    var run_strength: float = clampf((horizontal_speed - 4.2) / 3.6, 0.0, 1.0)
    motion_time += delta * (3.8 + run_strength * 4.4) * maxf(0.12, walk_strength)

    var stride: float = sin(motion_time) * walk_strength * ground_blend
    var stride_back: float = sin(motion_time + PI) * walk_strength * ground_blend
    var arm_swing := 0.40 + run_strength * 0.16
    var leg_swing := 0.58 + run_strength * 0.18
    var crouch_leg_factor := lerpf(1.0, 0.55, crouch_blend)

    left_thigh.rotation.x = lerpf(left_thigh.rotation.x, stride * leg_swing * crouch_leg_factor, minf(1.0, delta * 12.0))
    right_thigh.rotation.x = lerpf(right_thigh.rotation.x, stride_back * leg_swing * crouch_leg_factor, minf(1.0, delta * 12.0))
    left_calf.rotation.x = lerpf(left_calf.rotation.x, maxf(0.0, -stride) * 0.42 + crouch_blend * 0.22, minf(1.0, delta * 12.0))
    right_calf.rotation.x = lerpf(right_calf.rotation.x, maxf(0.0, -stride_back) * 0.42 + crouch_blend * 0.22, minf(1.0, delta * 12.0))
    left_foot.rotation.x = lerpf(left_foot.rotation.x, minf(0.22, -left_calf.rotation.x * 0.5), minf(1.0, delta * 12.0))
    right_foot.rotation.x = lerpf(right_foot.rotation.x, minf(0.22, -right_calf.rotation.x * 0.5), minf(1.0, delta * 12.0))

    left_upper_arm.rotation.x = lerpf(left_upper_arm.rotation.x, -stride * arm_swing - crouch_blend * 0.30, minf(1.0, delta * 10.0))
    right_upper_arm.rotation.x = lerpf(right_upper_arm.rotation.x, -stride_back * arm_swing - crouch_blend * 0.30, minf(1.0, delta * 10.0))
    left_forearm.rotation.x = lerpf(left_forearm.rotation.x, -0.18 - crouch_blend * 0.28 + run_strength * 0.08, minf(1.0, delta * 10.0))
    right_forearm.rotation.x = lerpf(right_forearm.rotation.x, -0.18 - crouch_blend * 0.28 + run_strength * 0.08, minf(1.0, delta * 10.0))

    hips.position.y = 0.96 - 0.18 * crouch_blend + absf(sin(motion_time * 2.0)) * 0.018 * walk_strength
    hips.rotation.x = lerpf(hips.rotation.x, 0.06 * run_strength, minf(1.0, delta * 8.0))
    spine.rotation.x = lerpf(spine.rotation.x, 0.07 * run_strength + 0.16 * crouch_blend, minf(1.0, delta * 8.0))
    chest.rotation.x = lerpf(chest.rotation.x, 0.05 * run_strength + 0.12 * crouch_blend, minf(1.0, delta * 8.0))
    head.position.y = lerpf(head.position.y, 0.13 - 0.05 * crouch_blend, minf(1.0, delta * 8.0))
    head.rotation.x = lerpf(head.rotation.x, -0.04 + crouch_blend * 0.08, minf(1.0, delta * 8.0))

    if not on_ground:
        left_thigh.rotation.x = lerpf(left_thigh.rotation.x, -0.24, minf(1.0, delta * 5.0))
        right_thigh.rotation.x = lerpf(right_thigh.rotation.x, 0.20, minf(1.0, delta * 5.0))
        left_calf.rotation.x = lerpf(left_calf.rotation.x, 0.22, minf(1.0, delta * 5.0))
        right_calf.rotation.x = lerpf(right_calf.rotation.x, 0.10, minf(1.0, delta * 5.0))
