extends CharacterBody3D
# Version de diagnostic v0.4.3 : logique de zombies simple, visuel original humanoide.
var zombie_id := 0
var health := 3
var target_position := Vector3.ZERO
var main: Node3D
var speed := 2.3
var attack_cooldown := 0.0
var visual: Node3D
var time_walk := 0.0

func setup(id: int, pos: Vector3, world: Node3D) -> void:
    zombie_id = id
    name = "Zombie_%d" % id
    position = pos
    target_position = pos
    main = world

func _part(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> void:
    var mesh_node := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = size.x
    mesh.height = maxf(size.y, size.x * 2.0)
    mesh_node.mesh = mesh
    mesh_node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.96
    mesh_node.material_override = mat
    parent.add_child(mesh_node)

func _ready() -> void:
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.4
    shape.height = 1.7
    collision.shape = shape
    collision.position.y = 0.85
    add_child(collision)
    visual = Node3D.new()
    visual.name = "Zombie_Visuel"
    add_child(visual)
    var variation := float(zombie_id % 4) * 0.065
    var shirt := Color(0.30 + variation, 0.27, 0.22)
    var skin := Color(0.52, 0.57 - variation, 0.46)
    var trouser := Color(0.18, 0.18 + variation, 0.18)
    _part(visual, Vector3(0.22, 0.66, 0), Vector3(0, 1.22, 0.03), shirt)
    _part(visual, Vector3(0.20, 0.39, 0), Vector3(0, 1.75, -0.10), skin)
    _part(visual, Vector3(0.10, 0.68, 0), Vector3(-0.30, 1.11, -0.18), skin)
    _part(visual, Vector3(0.10, 0.68, 0), Vector3(0.30, 1.11, -0.18), skin)
    _part(visual, Vector3(0.13, 0.83, 0), Vector3(-0.14, 0.45, 0), trouser)
    _part(visual, Vector3(0.13, 0.83, 0), Vector3(0.14, 0.45, 0), trouser)
    visual.rotation.x = 0.13

func _physics_process(delta: float) -> void:
    if not main.game_started:
        return
    if multiplayer.has_multiplayer_peer() and not multiplayer.is_server():
        position = position.lerp(target_position, minf(1.0, delta * 8.0))
        return
    var nearest: Node3D = null
    var best_distance := 17.0
    for p in main.players.values():
        if not is_instance_valid(p):
            continue
        var dist: float = position.distance_to(p.position)
        if dist < best_distance:
            nearest = p
            best_distance = dist
    if nearest != null and best_distance > 1.1:
        var direction := nearest.position - position
        direction.y = 0.0
        direction = direction.normalized()
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
        rotation.y = atan2(-direction.x, -direction.z)
    else:
        velocity.x = move_toward(velocity.x, 0.0, delta * 5.0)
        velocity.z = move_toward(velocity.z, 0.0, delta * 5.0)
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = 0.0
    move_and_slide()
    time_walk += delta * (2.0 + Vector2(velocity.x, velocity.z).length())
    visual.position.y = sin(time_walk) * 0.03
    attack_cooldown -= delta
    if nearest != null and best_distance < 1.35 and attack_cooldown <= 0.0:
        attack_cooldown = 1.1
        main.zombie_attack(nearest.player_id, 10)

func take_hit() -> bool:
    health -= 1
    return health <= 0
