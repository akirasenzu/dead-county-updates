extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const ZombieScript = preload("res://scripts/zombie.gd")
const PORT := 27015
var game_started := false
var players := {}
var zombies := {}
var next_zombie_id := 1
var spawn_timer := 0.0
var sync_timer := 0.0
var rng := RandomNumberGenerator.new()
var menu: CanvasLayer
var status_text: Label
var ip_input: LineEdit
var hud: Label
var world_root: Node3D

func _ready() -> void:
	rng.seed = 20261014
	_build_menu()
	multiplayer.peer_connected.connect(_peer_joined)
	multiplayer.peer_disconnected.connect(_peer_left)
	multiplayer.connected_to_server.connect(_connected)
	multiplayer.connection_failed.connect(_connection_failed)
	multiplayer.server_disconnected.connect(_server_disconnected)

func _build_menu() -> void:
	menu = CanvasLayer.new()
	add_child(menu)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.055, 0.075, 0.09, 1.0)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(backdrop)

	# CentreContainer owns positioning. Never combine PRESET_CENTER with manual offsets.
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(500, 420)
	center.add_child(panel)
	var margins := MarginContainer.new()
	margins.add_theme_constant_override("margin_left", 24)
	margins.add_theme_constant_override("margin_right", 24)
	margins.add_theme_constant_override("margin_top", 22)
	margins.add_theme_constant_override("margin_bottom", 22)
	panel.add_child(margins)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	margins.add_child(layout)
	var title := Label.new()
	title.text = "DEAD COUNTY 3D"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 29)
	layout.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Prototype v0.4.3  |  Diagnostic zombies"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layout.add_child(subtitle)
	_add_button(layout, "JOUER EN SOLO", _start_solo)
	_add_button(layout, "HEBERGER UNE PARTIE (PORT 27015)", _host)
	ip_input = LineEdit.new()
	ip_input.text = "127.0.0.1"
	ip_input.placeholder_text = "Adresse IP de l'hote"
	layout.add_child(ip_input)
	_add_button(layout, "REJOINDRE UNE PARTIE", _join)
	status_text = Label.new()
	status_text.text = "Souris : camera | ZQSD : bouger | Shift : courir | Ctrl : s’accroupir | Espace : sauter | Clic gauche : frapper"
	status_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layout.add_child(status_text)

func _add_button(parent: Node, label: String, callback: Callable) -> void:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size.y = 48
	parent.add_child(btn)
	btn.pressed.connect(callback)

func _start_solo() -> void:
	_begin_world()
	_spawn_player(1)
	_spawn_initial_zombies()

func _host() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, 8)
	if err != OK:
		status_text.text = "Erreur serveur: %d" % err
		return
	multiplayer.multiplayer_peer = peer
	_begin_world()
	_spawn_player(1)
	_spawn_initial_zombies()

func _join() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip_input.text.strip_edges(), PORT)
	if err != OK:
		status_text.text = "Connexion impossible: %d" % err
		return
	multiplayer.multiplayer_peer = peer
	status_text.text = "Connexion en cours..."

func _connected() -> void:
	_begin_world()
	request_world_state.rpc_id(1)

func _connection_failed() -> void:
	status_text.text = "Echec de connexion. Verifiez l'IP et le pare-feu."
	multiplayer.multiplayer_peer = null

func _server_disconnected() -> void:
	get_tree().reload_current_scene()

func _peer_joined(id: int) -> void:
	if not multiplayer.is_server(): return
	# The newcomer requests the existing players and zombies after connecting.
	spawn_player.rpc(id)

func _peer_left(id: int) -> void:
	if players.has(id):
		players[id].queue_free()
		players.erase(id)

@rpc("any_peer", "reliable")
func request_world_state() -> void:
	if not multiplayer.is_server(): return
	var sender := multiplayer.get_remote_sender_id()
	for id in players.keys():
		spawn_player.rpc_id(sender, id)
	for zombie in zombies.values():
		spawn_zombie.rpc_id(sender, zombie.zombie_id, zombie.position)

@rpc("authority", "call_local", "reliable")
func spawn_player(id: int) -> void:
	if not game_started: _begin_world()
	_spawn_player(id)

func _spawn_player(id: int) -> void:
	if players.has(id): return
	var p = CharacterBody3D.new()
	p.set_script(PlayerScript)
	p.setup(id)
	world_root.add_child(p)
	players[id] = p

func _begin_world() -> void:
	if game_started: return
	game_started = true
	menu.hide()
	world_root = Node3D.new()
	world_root.name = "World"
	add_child(world_root)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.32, 0.41, 0.46)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.65, 0.69, 0.72)
	e.ambient_light_energy = 0.8
	env.environment = e
	world_root.add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.light_energy = 1.4
	world_root.add_child(sun)
	_make_box(Vector3(0, -0.55, 0), Vector3(150, 1, 150), Color(0.22, 0.31, 0.21), true)
	_make_box(Vector3(0, 0.02, 0), Vector3(9, 0.06, 150), Color(0.16, 0.17, 0.18), false)
	_make_box(Vector3(0, 0.03, 0), Vector3(150, 0.06, 9), Color(0.16, 0.17, 0.18), false)
	# Deterministic geometry, identical for all connected players.
	for x in range(-4, 5):
		for z in range(-4, 5):
			if abs(x) < 1 and abs(z) < 1: continue
			if x == 0 or z == 0: continue
			var h := 4.0 + float(abs(x * 7 + z * 3) % 4) * 1.8
			var pos := Vector3(x * 14.0, h / 2.0, z * 14.0)
			var c := Color(0.42 + float(abs(x) % 3)*0.08, 0.36, 0.30)
			_make_box(pos, Vector3(8, h, 8), c, true)
	var hud_layer := CanvasLayer.new()
	add_child(hud_layer)
	hud = Label.new()
	hud.position = Vector2(16, 14)
	hud.add_theme_font_size_override("font_size", 19)
	hud_layer.add_child(hud)

func _make_box(pos: Vector3, size: Vector3, color: Color, collidable: bool) -> void:
	var root: Node3D = StaticBody3D.new() if collidable else Node3D.new()
	root.position = pos
	world_root.add_child(root)
	var mesh := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mesh.mesh = b
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material_override = mat
	root.add_child(mesh)
	if collidable:
		var collider := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		collider.shape = shape
		root.add_child(collider)

func _spawn_initial_zombies() -> void:
	# Quelques zombies sur la route, visibles depuis le point de depart.
	# Le reste est reparti sur les rues pour ne pas apparaitre dans les maisons.
	var starts := [
		Vector3(-2.0, 0.3, -10.0),
		Vector3(1.7, 0.3, -15.0),
		Vector3(-1.6, 0.3, -21.0),
		Vector3(2.2, 0.3, -28.0),
		Vector3(-3.0, 0.3, -35.0),
		Vector3(12.0, 0.3, -1.8),
		Vector3(-17.0, 0.3, 2.1)
	]
	for pos in starts:
		_spawn_zombie_networked(pos)
	for i in range(8):
		_create_zombie()

func _spawn_zombie_networked(pos: Vector3) -> void:
	if multiplayer.has_multiplayer_peer():
		spawn_zombie.rpc(next_zombie_id, pos)
	else:
		_spawn_zombie(next_zombie_id, pos)
	next_zombie_id += 1

func _create_zombie() -> void:
	# Apparition uniquement sur les axes des rues.
	var dist := rng.randf_range(20.0, 56.0)
	var side := -1.0 if rng.randi_range(0, 1) == 0 else 1.0
	var lane := rng.randf_range(-2.8, 2.8)
	var pos := Vector3(lane, 0.3, dist * side)
	if rng.randi_range(0, 1) == 0:
		pos = Vector3(dist * side, 0.3, lane)
	_spawn_zombie_networked(pos)

@rpc("authority", "call_local", "reliable")
func spawn_zombie(id: int, pos: Vector3) -> void:
	if not game_started: _begin_world()
	_spawn_zombie(id, pos)

func _spawn_zombie(id: int, pos: Vector3) -> void:
	if zombies.has(id): return
	var z = CharacterBody3D.new()
	z.set_script(ZombieScript)
	z.setup(id, pos, self)
	world_root.add_child(z)
	zombies[id] = z

func _physics_process(delta: float) -> void:
	if not game_started: return
	var own_id := multiplayer.get_unique_id() if multiplayer.has_multiplayer_peer() else 1
	var hp := 0
	if players.has(own_id): hp = players[own_id].health
	hud.text = "DEAD COUNTY 3D v0.4.3 | Vie: %d | Zombies: %d | Joueurs: %d\nSouris: camera | ZQSD: bouger | Shift: courir | Ctrl: accroupi | Espace: sauter | Clic gauche: frapper | Echap: souris" % [hp, zombies.size(), players.size()]
	if multiplayer.has_multiplayer_peer() and not multiplayer.is_server(): return
	spawn_timer += delta
	if spawn_timer >= 15 and zombies.size() < 35:
		spawn_timer = 0
		_create_zombie()
	if multiplayer.has_multiplayer_peer():
		sync_timer += delta
		if sync_timer > 0.1:
			sync_timer = 0
			for z in zombies.values(): update_zombie.rpc(z.zombie_id, z.position, z.rotation.y)

@rpc("authority", "unreliable")
func update_zombie(id: int, pos: Vector3, yaw: float) -> void:
	if zombies.has(id):
		zombies[id].target_position = pos
		zombies[id].rotation.y = yaw

func _unhandled_input(event: InputEvent) -> void:
	if not game_started: return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		var my_id := multiplayer.get_unique_id() if multiplayer.has_multiplayer_peer() else 1
		if not players.has(my_id): return
		if multiplayer.has_multiplayer_peer() and not multiplayer.is_server(): request_attack.rpc_id(1)
		else: _perform_attack(my_id)

@rpc("any_peer", "reliable")
func request_attack() -> void:
	if not multiplayer.is_server(): return
	_perform_attack(multiplayer.get_remote_sender_id())

func _perform_attack(id: int) -> void:
	if not players.has(id): return
	var p: Node3D = players[id]
	var closest_id := -1
	var closest_dist := 2.6
	for zid in zombies.keys():
		var z: Node3D = zombies[zid]
		var dist := p.position.distance_to(z.position)
		if dist < closest_dist:
			closest_id = zid
			closest_dist = dist
	if closest_id >= 0 and zombies[closest_id].take_hit():
		if multiplayer.has_multiplayer_peer(): remove_zombie.rpc(closest_id)
		else: remove_zombie(closest_id)

@rpc("authority", "call_local", "reliable")
func remove_zombie(id: int) -> void:
	if not zombies.has(id): return
	zombies[id].queue_free()
	zombies.erase(id)

func zombie_attack(id: int, damage: int) -> void:
	if not players.has(id): return
	players[id].health = max(0, players[id].health - damage)
	if players[id].health == 0:
		players[id].health = 100
		players[id].position = Vector3(0, 2, 0)
	if multiplayer.has_multiplayer_peer(): set_player_health.rpc(id, players[id].health)

@rpc("authority", "call_local", "reliable")
func set_player_health(id: int, hp: int) -> void:
	if players.has(id): players[id].health = hp
